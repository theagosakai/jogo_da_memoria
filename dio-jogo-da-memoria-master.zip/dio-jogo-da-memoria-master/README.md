# Jogo da memória com JavaScript

Projeto desenvolvido durante o bootcamp React Web Developer da Digital Innovation One.

**Objetivo:** aprender efeitos 3D no CSS, lógica de programação com condicionais, Immediately Invoked Function Expression e manipulação de Arrays.

<img src="https://github.com/isabelavs/dio-jogo-da-memoria/blob/master/img/jogo-da-memoria.gif" alt="gif do jogo">
